Курсов проект по Планиране на експеримента - V15
===================================================
Студент : Тенчо Гюлтенов Бостанджиев
Фак. №  : 471223079
Група   : 76
Вариант : V15 - Производствена клетка / електроенергийно натоварване / подвариант C
Фактор  : z_t = Външна среда / товарен индекс

Среда:
  Python 3.11.9 (Windows)
  numpy, pandas, matplotlib, scipy, jupyter, reportlab

Команди за стартиране (от корена на архива):
  1) Инсталация на зависимости:
       py -3.11 -m pip install numpy pandas matplotlib scipy jupyter reportlab

  2) Изпълнение на pipeline-a (всичките 7 етапа):
       py -3.11 -m jupyter nbconvert --to notebook --execute "source/15 - V15 - Тенчо Гюлтенов Бостанджиев - шаблон.ipynb" --output "../source/15 - V15 - Тенчо Гюлтенов Бостанджиев - шаблон.ipynb"

     или интерактивно:
       py -3.11 -m jupyter notebook "source/15 - V15 - Тенчо Гюлтенов Бостанджиев - шаблон.ipynb"
     и Cell -> Run All.

  Notebook-ът автоматично разпознава дали е стартиран от корена на архива
  или от папката source/ и винаги пише изходните файлове в корена.

Структура на архива:
  source/                  - изходен код (Jupyter notebook)
  results/                 - графики (PNG) от всичките етапи
  V15_raw.csv              - суров входен файл (120 наблюдения, t = 1..120)
  V15_future.csv           - бъдещи стойности на регресорите (t = 121..126)
  CLEAN.csv                - почистени данни след Етап 1
                             колони: t, x_norm, z_factor, y_raw, y_clean,
                                     is_missing, is_outlier, y_smooth
  forecast.csv             - стохастична прогноза за t = 121..126
                             колони: t, x_norm, z_factor, y_forecast,
                                     lower95, upper95
  report.pdf               - отчет (теория, метод, резултати, изводи)
  README.txt               - този файл
